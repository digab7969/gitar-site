
// Создание плавающих частиц
function createFloatingParticles() {
    const particlesContainer = document.createElement('div');
    particlesContainer.className = 'floating-particles';
    document.body.appendChild(particlesContainer);

    for (let i = 0; i < 15; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        
        const size = Math.random() * 8 + 4;
        particle.style.width = size + 'px';
        particle.style.height = size + 'px';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.animationDelay = Math.random() * 6 + 's';
        particle.style.animationDuration = (Math.random() * 4 + 4) + 's';
        
        particlesContainer.appendChild(particle);
    }
}

// Плавная прокрутка к элементам
function smoothScroll(target) {
    document.querySelector(target).scrollIntoView({
        behavior: 'smooth'
    });
}

// Анимация появления элементов при прокрутке
function animateOnScroll() {
    const elements = document.querySelectorAll('.guitar-card, .fact-section');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    });

    elements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease-out';
        observer.observe(el);
    });
}

// Интерактивные звуковые эффекты (визуальная имитация)
function addSoundEffects() {
    const guitarCards = document.querySelectorAll('.guitar-card');
    
    guitarCards.forEach((card, index) => {
        card.addEventListener('click', () => {
            // Создаем визуальный эффект "звуковой волны"
            const wave = document.createElement('div');
            wave.style.position = 'absolute';
            wave.style.width = '20px';
            wave.style.height = '20px';
            wave.style.borderRadius = '50%';
            wave.style.background = 'rgba(102, 126, 234, 0.5)';
            wave.style.top = '50%';
            wave.style.left = '50%';
            wave.style.transform = 'translate(-50%, -50%)';
            wave.style.animation = 'soundWave 0.6s ease-out forwards';
            wave.style.pointerEvents = 'none';
            
            card.style.position = 'relative';
            card.appendChild(wave);
            
            setTimeout(() => {
                wave.remove();
            }, 600);
            
            // Показываем информацию о гитаре
            showGuitarInfo(index);
        });
    });
}

// Показать информацию о гитаре
function showGuitarInfo(index) {
    const guitarInfo = [
        {
            name: "Электрогитара",
            description: "Идеальна для рока, металла и современной музыки. Звук усиливается электроникой.",
            sound: "Мощный, искаженный звук 🎸"
        },
        {
            name: "Акустическая",
            description: "Классический выбор для исполнителей. Естественный резонансный звук.",
            sound: "Теплый, натуральный звук 🎵"
        },
        {
            name: "Классическая",
            description: "Нейлоновые струны, широкий гриф. Идеальна для фламенко и классики.",
            sound: "Мягкий, мелодичный звук 🎼"
        }
    ];
    
    const info = guitarInfo[index];
    const modal = createInfoModal(info);
    document.body.appendChild(modal);
}

// Создание модального окна с информацией
function createInfoModal(info) {
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000;
        animation: fadeIn 0.3s ease;
    `;
    
    const content = document.createElement('div');
    content.style.cssText = `
        background: linear-gradient(145deg, #ffffff, #f8f9fa);
        padding: 30px;
        border-radius: 20px;
        max-width: 400px;
        text-align: center;
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
    `;
    
    content.innerHTML = `
        <h3 style="color: #667eea; margin-bottom: 15px;">${info.name}</h3>
        <p style="margin-bottom: 15px;">${info.description}</p>
        <div style="font-size: 18px; margin-bottom: 20px;">${info.sound}</div>
        <button class="pulse-btn" onclick="this.parentElement.parentElement.remove()">
            Закрыть
        </button>
    `;
    
    modal.appendChild(content);
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
        }
    });
    
    return modal;
}

// Добавление кнопки "Наверх"
function addScrollToTopButton() {
    const button = document.createElement('button');
    button.innerHTML = '↑';
    button.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: linear-gradient(45deg, #667eea, #764ba2);
        color: white;
        border: none;
        font-size: 20px;
        cursor: pointer;
        z-index: 1000;
        opacity: 0;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    `;
    
    button.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            button.style.opacity = '1';
        } else {
            button.style.opacity = '0';
        }
    });
    
    document.body.appendChild(button);
}

// Добавление CSS анимаций
function addCustomStyles() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideIn {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes soundWave {
            from { 
                transform: translate(-50%, -50%) scale(1);
                opacity: 0.8;
            }
            to { 
                transform: translate(-50%, -50%) scale(10);
                opacity: 0;
            }
        }
        
        .guitar-card {
            cursor: pointer;
        }
        
        .guitar-card:active {
            transform: translateY(-8px) scale(0.98);
        }
    `;
    document.head.appendChild(style);
}

// Инициализация всех эффектов
document.addEventListener('DOMContentLoaded', () => {
    createFloatingParticles();
    animateOnScroll();
    addSoundEffects();
    addScrollToTopButton();
    addCustomStyles();
    
    // Добавляем приветственное сообщение
    setTimeout(() => {
        const welcome = document.createElement('div');
        welcome.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            z-index: 1000;
            animation: slideInRight 0.5s ease;
        `;
        welcome.innerHTML = '🎸 Добро пожаловать в мир гитар!';
        document.body.appendChild(welcome);
        
        setTimeout(() => {
            welcome.style.animation = 'slideOutRight 0.5s ease forwards';
            setTimeout(() => welcome.remove(), 500);
        }, 3000);
    }, 1000);
});

// Дополнительные анимации для приветствия
const additionalStyles = document.createElement('style');
additionalStyles.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); }
        to { transform: translateX(0); }
    }
    
    @keyframes slideOutRight {
        from { transform: translateX(0); }
        to { transform: translateX(100%); }
    }
`;
document.head.appendChild(additionalStyles);
